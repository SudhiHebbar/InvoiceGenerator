import { Invoice } from '@/components/Invoice';

export default function Index() {
  return <Invoice />;
}
